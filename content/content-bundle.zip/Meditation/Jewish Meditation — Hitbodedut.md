# Jewish Meditation — Hitbodedut

> [!QUOTE]
> It is significant that Rabbi Nachman refers to this practice of speaking to God, not as prayer, but as meditation. It appears that the line between prayer and meditation here is a very fine one, but there is an important difference. When a person speaks to God spontaneously, whenever he feels impelled to do so, then it is prayer. When a person makes it a fixed practice and spends a definite time each day conversing with God, then it is meditation. As we have discussed earlier, meditation is thinking in a controlled manner. If this thinking consists in a conversation with God, it is no less a meditative experience.
> 
> In this context, Rabbi Nachman prescribes making a commitment to spending a fixed amount of time each day speaking to God. The amount of time he prescribes is approximately an hour every evening. In our fast-moving modern society, many find twenty to thirty minutes a more comfortable period for such conversation. The main thing is that it be for a fixed period of time and that it be practiced every day without fail.
> 
> The most difficult thing is to begin. Rabbi Nachman advises sitting down in the place where you meditate and saying to yourself, “For the next twenty mintes, I will be alone with God.” This in itself is significant, since it is like the beginning of a “visit.” Even if there is nothing to say, it is a valid experience since you are spending time alone with God, aware of His presence. If you sit long enough, says Rabbi Nachman, you will eventually find something to say.
> 
> If you have difficulty in beginning the conversation, Rabbi Nachman advises repeating the phrase “Master of the Universe” over and over. This can comprise the entire conversation. When you say these words, be aware that you are calling out to God. Eventually, your thoughts will open up, and you will find other ways of expressing yourself.
> 
> Of course, “Master of the Universe” is nothing other than _Ribbono shel Olam_, a phrase that I discussed earlier as a Jewish mantra. Here we see that it can also be used to call out to God in a most basic way, to establish communication.
> 
> If you still cannot begin speaking with God, Rabbi Nachman suggests making this difficulty itself the point of conversation. Tell God how much you would like to speak to Him. Explain to Him that it is hard for you to find something to say. Ask God to help you find words with which to address Him. Discuss the problem with Him as you would with a good friend. Once the conversation has begun, it is usually easy to continue.
> 
> Another point of departure can be the feeling of alienation and distance from God. You can initiate a conversation by asking God to bring you closer to Him. Tell him how far you feel from Him and how much closer you would like to be. Ask Him to help you find such closeness.

_From [Jewish Meditation]((https://www.google.com/books/edition/Jewish_Meditation/Bp_U6ucBSh0C?hl=en)) by Aryeh Kaplan, pgs. 94-95._