
## Meditation

- [[Jewish Meditation — Hitbodedut]]

## Prayer

- [[Lauds — Opening Versicles in Latin]]