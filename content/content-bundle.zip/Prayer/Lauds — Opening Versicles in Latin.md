# Lauds — Opening Versicles in Latin

## Domine, labia mea aperies.

℣. Domine, labia mea aperies.
℟. Et os meum annunciabit laudem tuam.

℣. Lord, open our lips.
And we shall praise your name.

## Deus in adiutorium meum intende.

℣. Deus in adiutorium meum intende.
℟. Domine ad adiuvandum me festina.

℣. O God, come to our aid.
℟. O Lord, make haste to help us.